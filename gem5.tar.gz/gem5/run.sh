# ./build/X86/gem5.opt configs/example/fs.py \
#     --kernel="../linux-v5.14/vmlinux" \
#     --disk-image="/home/fsl/Desktop/3rdparty/buildroot-2022.05/output/images/rootfs.ext4"

# ./build/X86/gem5.opt configs/example/fs.py \
#     --kernel="/home/fsl/Desktop/disk/x86-base/vmlinux-5.4.49" \
#     --disk-image="/home/fsl/Desktop/disk/x86-base/base.img"
#     # --disk-image="/home/fsl/Desktop/3rdparty/buildroot-2022.05/output/images/rootfs.ext4" \
#     # --command-line="earlyprintk=ttyS0 console=ttyS0 lpj=7999923 root=/dev/hda"
#     # --command-line="root=/dev/hda earlyprintk=ttyS0 console=ttyS0 lpj=7999923 acpi=off nokaslr"
#     # --command-line="root=/dev/sda rw earlyprintk=ttyS0 console=ttyS0,115200 acpi=off nokaslr"

# ./build/X86/gem5.opt configs/example/fs.py \
#     --kernel="/home/fsl/Desktop/disk/x86-base/vmlinux-5.4.49" \
#     --disk-image="/home/fsl/Desktop/3rdparty/buildroot-2022.05/output/images/rootfs.ext4" \
#     --command-line="root=/dev/hda earlyprintk=ttyS0 console=ttyS0 lpj=7999923 acpi=off nokaslr"

# ./build/X86/gem5.opt configs/example/fs.py \
#     --kernel="/home/fsl/Desktop/disk/x86-base/vmlinux-5.4.49" \
#     --disk-image="/home/fsl/Desktop/disk/x86-base/base.img"

# ./build/X86/gem5.opt configs/example/fs.py \
#     --kernel="/home/fsl/Desktop/disk/x86-base/vmlinux-5.4.49" \
#     --disk-image="/home/fsl/Desktop/disk/x86-base/ubuntu.img" \
#     --command-line="earlyprintk=ttyS0 console=ttyS0 lpj=7999923 root=/dev/hda"

# ./build/X86/gem5.opt configs/example/fs.py \
#     --kernel="/home/fsl/Desktop/disk/x86-base/linux-v5.4/vmlinux" \
#     --disk-image="/home/fsl/Desktop/disk/x86-base/ubuntu.img" \
#     --command-line="earlyprintk=ttyS0 console=ttyS0 lpj=7999923 root=/dev/hda"

# ./build/X86/gem5.opt configs/example/fs.py \
#     --kernel="/home/fsl/Desktop/disk/x86-base/linux-v5.4/vmlinux" \
#     --disk-image="/home/fsl/Desktop/disk/x86-base/ubuntu.img" \
#     --command-line="earlyprintk=ttyS0 console=ttyS0 lpj=7999923 root=/dev/hda" \
#     --cpu-type="X86O3CPU" --caches --l2cache

./build/X86/gem5.opt configs/example/fs.py \
    --kernel="/home/fsl/Desktop/disk/x86-base/linux-v5.4/vmlinux" \
    --disk-image="/home/fsl/Desktop/disk/x86-base/insmod.img" \
    --command-line="earlyprintk=ttyS0 console=ttyS0 lpj=7999923 root=/dev/hda" \
    --cpu-type="X86O3CPU" --caches --l2cache



